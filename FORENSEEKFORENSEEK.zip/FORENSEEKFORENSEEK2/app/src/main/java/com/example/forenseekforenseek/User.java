package com.example.forenseekforenseek;

public class User {

    public  String fullname, email,pwd;

    public User(String fullname, String email, String password) {
        this.fullname = fullname;
        this.email = email;
        this.pwd = password;
    }

}


