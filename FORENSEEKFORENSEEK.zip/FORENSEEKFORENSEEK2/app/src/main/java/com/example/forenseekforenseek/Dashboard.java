package com.example.forenseekforenseek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;

public class Dashboard extends AppCompatActivity {

    Button  btndescription, btnlist,btntxtprnt, btnpeople,btntexttospeech,btnspeechtotext;

    TextView tvChangePass;


    private FirebaseAuth firebaseAuth;

    //this is the normal user screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        firebaseAuth = FirebaseAuth.getInstance();
        btndescription = findViewById(R.id.btnupdate);
        btntxtprnt = findViewById(R.id.btntxtprnt);
//        tvChangePass = findViewById(R.id.tvChangePassword);
        btnlist= findViewById(R.id.btnlist);
        btnpeople= findViewById(R.id.btnpeople);
        btntexttospeech= findViewById(R.id.btntxttospeech);
        btnspeechtotext= findViewById(R.id.btnspeechtotext);

        btnspeechtotext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Dashboard.this, Speechtotext.class);
                startActivity(i);
            }
        });
        btntxtprnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Dashboard.this, Txtprnt.class);
                startActivity(i);
            }
        });
        btnpeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Dashboard.this, Developerprofile.class);
                startActivity(i);
                // finish();
            }
        });

        btndescription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Dashboard.this, Description.class);
                startActivity(i);
                // finish();
            }
        });

        btnlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (getApplicationContext(), Singlerow.class));
            }
        });

        btntexttospeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (getApplicationContext(), Text2speech.class));
            }
        });
        }
    }
