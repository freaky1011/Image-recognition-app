package com.example.forenseekforenseek;

public class UserHelperClass {
    public int getID() {
        return 0;
    }

    public int getName() {
        return 0;
    }
}

