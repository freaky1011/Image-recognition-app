package com.example.forenseekforenseek;

import java.util.jar.Attributes;

public class Model
{
    String Name;
    String Record;
    String ID;
    String purl;

    Model()
    {

    }
    public Model(String Name, String Record, String ID, String purl) {
        this.Name = Name;
        this.Record = Record;
        this.ID = ID;
        this.purl = purl;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getRecord() {
        return Record;
    }

    public void setRecord(String Record) {
        this.Record = Record;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPurl() {
        return purl;
    }

   // public void setPurl(String purl) {
       // this.purl = purl;
   // }
}
